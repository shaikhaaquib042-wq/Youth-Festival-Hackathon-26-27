import base64, json, urllib.request
import streamlit as st

st.set_page_config(page_title="NyayaSahayak Pune", page_icon="⚖️", layout="centered")
st.title("⚖️ Where Do I Even Complain? (Pune)")
st.write("Speak or type your issue in English, Hindi, or Marathi to find the exact Pune authority and official portal.")

api_key = st.sidebar.text_input("Gemini API Key (Optional)", type="password")

def pune_fallback(area, issue, lang):
    t = (area + " " + issue).lower()
    if any(w in t for w in ["noise", "dj", "loud", "music", "police", "threat", "fight"]):
        return ("Public Nuisance / Noise Dispute", f"Pune City Police - {area.title()} Chowky", "112 | WhatsApp: 8975283100", "https://mahapolice.gov.in", "Call 112 for active noise after 10 PM or send video on Pune Police WhatsApp.", ["Timestamped audio/video proof", "Exact flat/street address", "Your ID proof"], f"To,\nSenior Police Inspector, {area.title()} Police Station, Pune.\n\nSubject: Complaint regarding disturbance in {area.title()}\n\nSir/Madam,\nI wish to report: {issue or 'Loud noise nuisance'}. Kindly take immediate action.\n\nYours faithfully,\n[Your Name]")
    elif any(w in t for w in ["deposit", "landlord", "rent", "flat", "tenant"]):
        return ("Rent & Security Deposit Dispute", f"Pune District Legal Services / Civil Mediation ({area.title()})", "15100 (Free Legal Aid)", "https://maharashtra.gov.in", "Send a 7-day written refund notice before filing for free mediation at Pune DLSA.", ["Leave & License Agreement", "Deposit payment receipt", "Key handover proof"], f"To,\nThe Landlord, {area.title()}, Pune.\n\nSubject: Refund of Security Deposit\n\nDear Sir/Madam,\nRegarding my tenancy in {area.title()}: {issue or 'My security deposit is overdue'}. Kindly refund within 7 days.\n\nSincerely,\n[Your Name]")
    ward = "PMC Ghole Road Ward Office (Shivajinagar)" if any(k in t for k in ["shivaji", "fc", "deccan", "ghole"]) else f"PMC {area.title()} Ward Office"
    return ("Civic & Municipal Grievance", ward, "1800-1030-222 | WhatsApp: 9689900002", "https://pmc.gov.in", "Register on PMC Care Portal to get a trackable Grievance Token ID.", ["Photo of issue with landmark", "Exact street/pole location", "Mobile number for SMS tracking"], f"To,\nThe Ward Officer, {ward}, Pune.\n\nSubject: Urgent civic issue in {area.title()}\n\nSir/Madam,\nPlease resolve this issue in {area.title()}: {issue or 'Unattended municipal issue'}.\n\nYours faithfully,\n[Your Name]")

def ask_gemini(key, area, issue, lang, audio_bytes):
    url = f"https://googleapis.com{key.strip()}"
    parts = [{"text": f"Pune civic/legal assistant. Area: {area}, Pune. Lang: {lang}. Issue: {issue}. Return JSON with keys: cat, auth, help, url (valid https:// Pune/India portal), step, docs (list of 3 strings), letter (formal complaint in {lang})."}]
    if audio_bytes:
        parts.append({"inline_data": {"mime_type": "audio/wav", "data": base64.b64encode(audio_bytes).decode()}})
    payload = {"contents": [{"parts": parts}], "generationConfig": {"response_mime_type": "application/json"}}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", "Connection": "close"})
    with urllib.request.urlopen(req, timeout=8) as r:
        d = json.loads(json.loads(r.read().decode())["candidates"].pop(0)["content"]["parts"].pop(0)["text"])
        return d["cat"], d["auth"], d["help"], d["url"], d["step"], d["docs"], d["letter"]

area = st.text_input("Your Area in Pune", placeholder="e.g., Shivajinagar, Kothrud, Baner")
lang = st.selectbox("Draft Language", ["English", "Marathi", "Hindi"])
audio_val = st.audio_input("Option A: Speak your problem")
issue = st.text_area("Option B: Or type your problem", placeholder="e.g., Garbage not picked up near Ghole Road for 4 days.")

if st.button("Find Where to Complain", type="primary"):
    if not area or (not issue and not audio_val):
        st.warning("Please enter your Pune area and either speak or type your issue.")
    else:
        with st.spinner("Finding right Pune authority..."):
            try:
                res = ask_gemini(api_key, area, issue, lang, audio_val.read() if audio_val else None) if api_key else pune_fallback(area, issue, lang)
            except Exception:
                res = pune_fallback(area, issue, lang)
            cat, auth, help_no, link, step, docs, letter = res
            st.success(f"**Category:** {cat}")
            st.info(f"**Authority:** {auth}\n\n**Helpline:** {help_no}")
            if str(link).startswith("http"):
                st.link_button("🌐 Go to Official Complaint Portal", link, type="primary")
            st.write(f"**First Step:** {step}")
            for d in docs:
                st.checkbox(d)
            st.text_area("Formal Complaint Letter:", value=letter, height=200)
            st.download_button("📥 Download Letter (.txt)", letter, file_name="Pune_Complaint.txt")