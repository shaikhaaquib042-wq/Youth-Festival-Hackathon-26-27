# ⚖️ NyayaSahayak Pune — Civic & Legal Grievance Router
**Built at Fergusson College Hackathon | Problem Statement: Peace Building & Conflict Prevention**

### 🎯 The Problem
Everyday civic, noise, consumer, and tenancy disputes often escalate into street-level conflict because citizens do not know *which authority* handles their issue or *how* to write a formal complaint.

### 💡 Our Solution
**NyayaSahayak Pune** is a multilingual (English, Marathi, Hindi) voice-and-text civic routing assistant that de-escalates disputes by giving citizens an instant, peaceful, institutional pathway:
- **Exact Local Routing:** Matches disputes to the exact **Pune Municipal Corporation (PMC) Ward Office** (e.g., Ghole Road Ward Office), **Pune City Police Chowky**, or **District Legal Services Authority**.
- **One-Click Official Portals:** Provides direct links to `pmc.gov.in`, `mahapolice.gov.in`, and emergency helplines (`112`, `1800-1030-222`).
- **Proof Checklist & Auto-Drafted Letter:** Generates a required document checklist and a downloadable formal complaint letter in English, Marathi, or Hindi.
- **Offline Resilient:** Built-in local routing fallback ensures uninterrupted operation even in low-connectivity areas.

### 🛠️ Tech Stack
- **Frontend & UI:** Python, Streamlit (Voice + Text Input)
- **AI & Routing Engine:** Google Gemini 2.5 Flash REST API + Verified Pune Civic Directory

### 🚀 How to Run Locally
1. Install Streamlit: `pip install streamlit`
2. Run the app: `streamlit run complain.py` (or double-click `start.bat` on Windows)
