@echo off
taskkill /F /IM python3.13.exe >nul 2>&1
cd /d C:\HTML
set PYTHONPATH=C:\HTML\libs
start http://127.0.0.1:8510
python3.13 -m streamlit run complain.py --global.developmentMode false --server.port 8510 --server.address 127.0.0.1